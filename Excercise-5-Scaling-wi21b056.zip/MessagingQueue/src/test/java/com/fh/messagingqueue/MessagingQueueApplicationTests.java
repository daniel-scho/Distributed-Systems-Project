package com.fh.messagingqueue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessagingQueueApplicationTests {

	@Test
	void contextLoads() {
	}

}
